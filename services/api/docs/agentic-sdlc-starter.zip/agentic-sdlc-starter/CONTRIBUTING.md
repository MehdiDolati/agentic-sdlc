# Contributing
- Use feature branches and Pull Requests
- Write tests and keep coverage above the configured gate
- Follow conventional commits where possible
