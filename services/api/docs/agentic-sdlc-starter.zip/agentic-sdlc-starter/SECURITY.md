# Security Policy
- Report vulnerabilities via private channels
- Dependencies are scanned in CI
