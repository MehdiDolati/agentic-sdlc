# Architecture Decision Record: <title>
## Context
## Decision
## Alternatives
## Consequences
