from pathlib import Path
from datetime import datetime
import re
import yaml

def _slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^a-z0-9\s-]', '', text)
    text = re.sub(r'[\s-]+', '-', text).strip('-')
    return text[:60] or "request"

def _today() -> str:
    return datetime.utcnow().strftime("%Y%m%d")

def plan_request(request_text: str, repo_root: Path) -> dict:
    """Generate PRD, ADR, User Stories and a simple task list from the request text.
    Returns a dict of artifact paths (relative to repo root).
    """
    slug = _slugify(request_text.splitlines()[0] if request_text else "request")
    date = _today()

    prd_dir = repo_root / "docs" / "prd"
    adr_dir = repo_root / "docs" / "adr"
    stories_dir = repo_root / "docs" / "stories"
    plans_dir = repo_root / "docs" / "plans"
    for d in (prd_dir, adr_dir, stories_dir, plans_dir):
        d.mkdir(parents=True, exist_ok=True)

    prd_path = prd_dir / f"PRD-{date}-{slug}.md"
    prd_md = f"""
    # Product Requirements Document — {request_text[:80]}

    ## Problem
    Summarize the core problem this request addresses.

    ## Goals / Non-goals
    - Goals: Deliver the requested functionality described in the user text.
    - Non-goals: Out-of-scope features not explicitly requested.

    ## Personas & Scenarios
    - Primary: End-user
    - Scenario: {request_text.strip()}

    ## Requirements (Must/Should/Could)
    - Must: Basic functionality that meets the acceptance criteria.
    - Should: Usability and simple docs.
    - Could: Nice-to-have improvements.

    ## Success Metrics
    - Endpoint(s) work as specified; tests pass.
    - Deployment succeeds without regression.

    ## Risks & Assumptions
    - Assumes standard stack per TEAM_PROFILE.
    """
    prd_path.write_text(prd_md.strip() + "\n", encoding="utf-8")

    adr_path = adr_dir / f"ADR-{date}-auto-planning.md"
    adr_md = f"""
    # Architecture Decision Record — Auto Planning
    ## Context
    Initial design decision for request: {request_text[:80]}

    ## Decision
    Use default stack from STACK_CONFIG/TEAM_PROFILE; refine as needed by orchestrator.

    ## Alternatives
    - Alternate frameworks or data stores per profile

    ## Consequences
    - Provides a baseline to iterate on in subsequent cycles.
    """
    adr_path.write_text(adr_md.strip() + "\n", encoding="utf-8")

    stories_path = stories_dir / f"USER_STORIES-{date}-{slug}.yaml"
    stories = [
        {
            "id": "US-0001",
            "persona": "end-user",
            "story": f"As an end-user, I want {request_text[:60]} so that I can achieve the desired outcome.",
            "acceptance_criteria": [
                "Given the system is running, When I invoke the relevant endpoint, Then I receive a valid response."
            ],
            "priority": "Must",
            "estimates": {"size": "S", "confidence": 0.6},
        }
    ]
    stories_yaml = yaml.safe_dump(stories, sort_keys=False, allow_unicode=True)
    stories_path.write_text(stories_yaml, encoding="utf-8")

    tasks_path = plans_dir / f"TASKS-{date}-{slug}.md"
    tasks_md = f"""
    # Task Plan — {request_text[:80]}

    - [ ] Clarify detailed acceptance criteria
    - [ ] Define API contract (OpenAPI)
    - [ ] Implement endpoint(s)
    - [ ] Write unit tests
    - [ ] Add integration tests (optional for MVP)
    - [ ] Update USER_MANUAL & CHANGELOG
    - [ ] Run CI; ensure coverage meets gate
    - [ ] Prepare deploy (staging)
    """
    tasks_path.write_text(tasks_md.strip() + "\n", encoding="utf-8")

    def rel(p: Path) -> str:
        return str(p.relative_to(repo_root).as_posix())

    return {
        "prd": rel(prd_path),
        "adr": rel(adr_path),
        "stories": rel(stories_path),
        "tasks": rel(tasks_path),
    }
