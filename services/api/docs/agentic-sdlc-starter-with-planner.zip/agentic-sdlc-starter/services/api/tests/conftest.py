import os, sys
from pathlib import Path

# add parent dir of tests to sys.path so 'import app' works
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
