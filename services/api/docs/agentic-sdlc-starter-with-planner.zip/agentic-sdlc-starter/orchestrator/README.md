# Orchestrator

Stubs for:
- Agent Registry (available agents/tools)
- Capability Graph (tasks → skills → tools)
- Planner/Scheduler (assign tasks based on profile & constraints)
- Config Loader (parses STACK_CONFIG/TEAM_PROFILE/runtime-config)
