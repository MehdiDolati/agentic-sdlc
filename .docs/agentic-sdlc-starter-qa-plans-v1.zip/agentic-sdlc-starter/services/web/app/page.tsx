export default function Home(){return(<main style={{padding:24}}><h1>Agentic SDLC Portal</h1><p>Welcome!</p></main>);}
